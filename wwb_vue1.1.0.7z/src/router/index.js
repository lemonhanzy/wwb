import { createRouter, createWebHashHistory } from "vue-router";
export default createRouter({
    history:createWebHashHistory(),
    routes:[
        {
            path:"/",
            component:()=>import("../views/Login.vue")
        },
        {
            path:"/login",
            component:()=>import("../views/Login.vue")
        },
        {
            path:"/index",
            component:()=>import("../views/Index.vue")
        },
        {
            path:"/reg",
            component:()=>import("../views/Reg.vue")
        }
    ]
})