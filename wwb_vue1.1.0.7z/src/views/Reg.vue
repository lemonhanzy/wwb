<template>
  <div class="login-container">
    <h2 class="login_h2">注册</h2>
    <div>
      <input
        class="login_input"
        type="text"
        placeholder="手机号"
        required
        v-model="obj.user.phone"
      />
      <input
        class="login_input"
        type="password"
        placeholder="密码"
        required
        v-model="obj.user.password"
      />
      <button @click="reg" class="login_button">注册</button>
      <a class="login_a" @click.prevent @click="go_login"
        >已有账号？点击这里登录</a
      >
    </div>
  </div>
</template>

<script setup>
import axios from "axios";
import { reactive } from "vue";
import { useRouter } from "vue-router";
let router = useRouter();
const obj = reactive({
  user: {
    phone: "",
    password: "",
  },
});
function reg() {
    if(obj.user.phone==""||obj.user.password==""){
        alert("手机和密码不能为空")
    }else{
        axios.post("http://localhost:8080/user/reg", {
      phone: obj.user.phone,
      password: obj.user.password
    })
    .then((res) => {
      if (res.data.code === 200) {
        alert("注册成功");
        go_login();
      } else {
        alert("注册失败，用户名重复");
      }
    });
    }

}
function go_login() {
  router.push("/login");
}
</script>

<style>
body {
  width: 100vh;
  height: 100vh;
  margin: 0;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background: linear-gradient(to right, #4caf50, #2196f3);
  transition: background-color 0.5s ease-in-out;
}
.login-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 0.8);
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
  width: 350px;
  height: 300px;
  margin: auto;
  text-align: center;
  transition: background-color 0.5s ease-in-out;
}

.login-container:hover {
  background: rgba(255, 255, 255, 0.9);
}

.login_h2 {
  color: #333;
}

.login_input {
  width: 100%;
  padding: 10px;
  margin: 10px 0;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-sizing: border-box;
}

.login_button {
  background-color: #4caf50;
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  width: 100px;
}

.login_button:hover {
  background-color: #45a049;
}
a {
  position: absolute;
  bottom: 10px;
  right: 10px;
  font-size: 12px;
  text-decoration: none;
  color: #333;
}
</style>
