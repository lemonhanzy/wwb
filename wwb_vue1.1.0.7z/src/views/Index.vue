<template>
    <div class="common-layout">
      <el-container>
        <el-header style="background-color: red;">Header</el-header>
        <el-container>
          <el-aside width="200px" style="background-color: skyblue;">Aside</el-aside>
          <el-main style="background-color: yellow;">Main</el-main>
          <el-aside width="200px" style="background-color: skyblue;">Aside</el-aside>
        </el-container>
      </el-container>
    </div>
  </template>

<script setup>

</script>

<style lang="scss" scoped>

</style>